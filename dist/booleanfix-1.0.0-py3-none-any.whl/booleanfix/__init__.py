# booleanfix/__init__.py

true = True
false = False
