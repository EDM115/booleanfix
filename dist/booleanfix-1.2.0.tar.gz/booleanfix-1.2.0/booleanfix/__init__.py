# booleanfix/__init__.py

true = True
false = False
none = None
null = None
undefined = None
